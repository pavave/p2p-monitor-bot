
import asyncio
import logging
from aiogram import Bot, Dispatcher, types
from config import TOKEN
from parser import get_best_prices
from database import save_price

logging.basicConfig(level=logging.INFO)
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=["start"])
async def start(message: types.Message):
    await message.reply("Привет! Я мониторю P2P-цены USDT/UAH на биржах 🚀")

@dp.message_handler(commands=["prices"])
async def get_prices(message: types.Message):
    args = message.text.split()
    bank = None
    min_limit, max_limit = 0, float("inf")

    if len(args) > 1:
        for arg in args[1:]:
            if arg.isdigit():
                if min_limit == 0:
                    min_limit = int(arg)
                else:
                    max_limit = int(arg)
            else:
                bank = arg

    prices = get_best_prices(bank, min_limit, max_limit)
    
    text = f"🔥 P2P цены USDT/UAH (банк: {bank if bank else 'любой'}, лимиты: {min_limit}-{max_limit} UAH):

"
    for exchange, price in prices.items():
        text += f"🔹 {exchange.capitalize()}: {price} UAH
"
        save_price(exchange, price)
    
    await message.reply(text)

async def price_monitor():
    while True:
        prices = get_best_prices()
        best_price = min(prices.values(), default=float("inf"))
        if best_price < 39:
            await bot.send_message(123456789, f"⚡ Цена упала до {best_price} UAH!")
        await asyncio.sleep(300)

async def main():
    asyncio.create_task(price_monitor())
    await dp.start_polling()

if __name__ == "__main__":
    asyncio.run(main())
    