
import os
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
DB_PATH = "p2p_data.db"
P2P_URLS = {
    "binance": "https://p2p.binance.com/bapi/c2c/v2/friendly/c2c/adv/search",
    "bybit": "https://api2.bybit.com/fiat/otc/item/list",
    "okx": "https://www.okx.com/v3/c2c/trading/orders",
}
    